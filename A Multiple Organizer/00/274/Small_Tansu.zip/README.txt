                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3663657
Small Tansu by richardlawler is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This small scale tansu was inspired by a mizuya-style kitchen tansu. Fusion 360 was used to design the model at 1/5th scale. The tansu model was designed for construction using laser cutting techniques with 5 mm plywood and glue. Eight brass screws are used to hold the door hinge brackets in place and facilitate their removal. All other hinges and joints were designed in Fusion 360 and made from plywood. There are 187 parts in the assembly - 22 independently moving parts including 12 drawers, 4 doors and one pull out chest with its own articulated, bifold hinged lid. 

This small tansu was intended to be a desktop secretary, but it could be use to store other things.

Small Tansu on A360 [Small Tansu Fusion 360](https://a360.co/2TNdeVC)

Blog post [Small Tansu](https://blog.microcarpentry.com/2019/03/the-tiny-tansu.html)

# Post-Printing

## Export DXF files or use provided files

Use provided DXF files or export DXF files from Fusion sketches of body faces.

DXF4Laser will create most faces. (There are a few faces were DXF4Laser will fail. These DXFs must be created by selecting face; create sketch; save sketch as DXF.)

Note: DXF4Laser must be used from component design files. It will not work on faces in composite assembly project because the components are read-only. So each component must be opened separately to do DXF file exporting. (This is just a limitation of DXF4Laser.)

0.0mm kerf setting is used in creating DXF files with DXF4Laser, but you may need to experiment with your material and laser cutter settings.

## Cut DXF files on suitable laser cutter

Cut DXF files from 5 mm plywood or other suitable sheet material. 

Laser cutter must have a cutting area of at least 600 mm x 285 mm. (23.7" x 11.25")

Drawer components will require duplicates: 3 upper small drawers; 5 upper large drawers; 4 lower large drawers.

Upper and lower door components will require mirrored duplicates. (Be sure to flip the DXFs for the preferred face of your material if it has one.) 

## Main "Tansu" assembly must start from the core components

Start from the three core components: Upper, LowerLower and UpperLower.

Then add the OuterBox and OuterFrame. 

Care must be taken since all components precisely interlink with others. 

## Build drawers, doors and upper right box separately


## Attach doors into upper left and lower cavities with small screws

Suggest pre-drilling pilot holes to match holes in brackets. 

## Optional: glue stops into the cavities to anchor shut door positions

Suggest using small pieces of 5 mm x 5 mm of sheet material 15 to 20 mm in length

# How I Designed This

![Alt text](https://cdn.thingiverse.com/assets/09/4d/7f/83/21/IMG_20170706_172332.jpg)
Design inspiration: mizuya-style kitchen tansu.

![Alt text](https://cdn.thingiverse.com/assets/70/66/34/d9/b3/IMG_20170706_170120.jpg)
Work in progress.

# Laser Cutting

## Laser Cutting

This design assumes material thickness of 5 mm throughout. 
The largest pieces require a laser cutter with a cutting area of 600 mm x 285 mm. 
(23.7" x 11.25")